<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $cogear->get('site.lang', 'en'); ?>">
    <head>
        <title><?php echo $meta->title->toString($cogear->get('site.title_separator',' &laquo; ')); ?></title>
        <meta type="keywords" content="<?php echo $meta->keywords->toString(', '); ?>"/>
        <meta type="description" content="<?php echo $meta->description; ?>"/>
        <?php echo $meta->info; ?>
        <?php echo $scripts; ?>
        <?php echo $styles; ?>
        <?event('theme.head.meta')?>
    </head>
<body>

    <?
        //@todo: Do something with me!  Where should I be?
        event('theme.body.before')
    ?> 
<div class="container">
    <!-- HEADER -->
    <div class="header">
        <a href="<?= Url::link('/admin')?>"><img src="<?= $theme->folder ?>/img/logo.png" class="header_logo" alt="COGEAR" /></a>
        <h2><?=HTML::a(Url::link('http://'.SITE_URL),$cogear->get('site.name',SITE_URL));?></h2>
        <div class="header_auth">
            
            <?= t('Welcome, ', 'User'); ?> <a href="<?= Url::gear('user',$cogear->user->login)?>" class="user_link"><?= $cogear->user->login; ?></a>
            | <a href="<?= Url::gear('user','logout'); ?>"><?= t('Logout', 'User'); ?></a>
        </div>
    </div>
    <!-- /HEADER -->


    <div class="content_wrapper">
        <div class="content_column">
            <!-- horizontal menu -->
            <ul class="top_menu">
                <li class="active"><a href="#">Управление пользователями</a></li>
                <li><a href="#">Права доступа</a></li>
                <li><a href="#">Группы</a></li>
                <li><a href="#">Создать</a></li>
                <li class="right"><a href="#">Помощь</a></li>
            </ul>
            <!-- /horizontal menu -->
            <div class="top_title">
                <h1>Управлятор управления пользователями</h1>
            </div>
            <div class="content_body">

            <!-- CONTENT --> 
            <?= $content?> 
            <!-- /CONTENT --> 

            </div>
        </div>
    </div>


    <!-- SIDEBAR -->
    <div class="sidebar">
        <!-- sidebar menu -->
        <a href="#" class="sidebar_hider visible"></a>
        <div class="sidebar_menu sidebar_menu_visible">
        <?= $sidebar?> 
        
            <ul id="sidebar_menu_ul">
                <li><a href="#"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/dashboard.png" alt="" />Главная панель</a></li>
                <li><a href="#"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/gear.png" alt="" />Шестеренки</a></li>
                <li><a href="#"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/television-image.png" alt="" />Внешний вид</a></li>
                <li><a href="#" class="active"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/users.png" alt="" />Пользователи</a>
                    <ul>
                        <li><a href="#">Управление пользователями</a></li>
                        <li><a href="#">Права доступа</a></li>
                        <li><a href="#">Группы</a></li>
                        <li><a href="#">Создать</a></li>
                    </ul>
                </li>
                <li><a href="#"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/ui-menu-blue.png" alt="" />Меню</a>
                    <ul>
                        <li><a href="#">Все меню</a></li>
                        <li><a href="#">Создать меню</a></li>
                    </ul>
                </li>
                <li><a href="#"><img src="http://p.yusukekamiyamane.com/icons/search/fugue/icons/wrench.png" alt="" />Настройки сайта</a></li>
            </ul>
        </div>
        <!-- /sidebar menu -->
    </div>
    <!-- /SIDEBAR -->


    <!-- FOOTER -->
    <div class="footer">
        <div class="footer_gear"> </div>
        <a href="http://cogear.ru" class="footer_logo_text" title="Сайт сообщества COGEAR">cogear <span>v.2.01</span></a>
        <div class="footer_stat">
            <?= $footer ?>
        </div>
    </div>
    <!-- /FOOTER -->


</div>

<?event('theme.body.after')?>

</body>
</html>
