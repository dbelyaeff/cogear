<?php
return array(
    'base' => 'admin',
);